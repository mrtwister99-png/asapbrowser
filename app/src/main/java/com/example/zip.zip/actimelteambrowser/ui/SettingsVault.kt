package com.example.actimelteambrowser.ui

import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.PersistableBundle
import android.view.WindowManager
import androidx.activity.compose.BackHandler
import androidx.annotation.RequiresApi
import javax.crypto.Cipher
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.consumeWindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.waitForUpOrCancellation
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.ui.text.style.TextAlign
import com.example.actimelteambrowser.core.settings.AppSettings
import kotlinx.coroutines.delay
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.actimelteambrowser.AppToast
import com.example.actimelteambrowser.core.vault.PinResult
import com.example.actimelteambrowser.core.vault.VaultBackup
import com.example.actimelteambrowser.core.vault.VaultCrypto
import com.example.actimelteambrowser.core.vault.VaultManager
import com.example.actimelteambrowser.data.VaultEntry
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

// Trezor hesel: zalozeni (12 slov + kontrola), odemknuti, seznam, detail, pridani / uprava, obnova ze zalohy.
// Hesla jsou jen v zasifrovanem souboru; po odemceni jsou v pameti, po zamknuti zmizi.


private enum class VaultStage { INTRO, WORDS, CHECK, LOCKED, LIST }

@Composable
fun VaultScreen(onBack: () -> Unit) {
    val context = LocalContext.current
    val activity = context as? Activity
    // 12 slov a hesla nejdou nafotit ani zaznamenat obrazovku
    DisposableEffect(Unit) {
        activity?.window?.addFlags(WindowManager.LayoutParams.FLAG_SECURE)
        onDispose { activity?.window?.clearFlags(WindowManager.LayoutParams.FLAG_SECURE) }
    }
    var stage by remember {
        mutableStateOf(
            if (!VaultManager.isCreated(context)) VaultStage.INTRO
            else if (VaultManager.isUnlocked) VaultStage.LIST
            else VaultStage.LOCKED
        )
    }
    // po automatickem zamknuti (15 min na pozadi) se z odemceneho seznamu vrati na zamek
    DisposableEffect(Unit) {
        val lc = (context as? androidx.activity.ComponentActivity)?.lifecycle
        val obs = androidx.lifecycle.LifecycleEventObserver { _, ev ->
            if (ev == androidx.lifecycle.Lifecycle.Event.ON_START && stage == VaultStage.LIST && !VaultManager.isUnlocked) stage = VaultStage.LOCKED
        }
        lc?.addObserver(obs)
        onDispose { lc?.removeObserver(obs) }
    }
    var phrase by remember { mutableStateOf("") }
    var introError by remember { mutableStateOf<String?>(null) }

    // pruvodce "co je trezor": poprve sam, pak kdykoli otaznikem vpravo dole
    var help by remember { mutableStateOf(!AppSettings.vaultDemoSeen.get()) }
    Column(Modifier.fillMaxSize().background(BG)) {
        Box(Modifier.weight(1f).consumeWindowInsets(WindowInsets.navigationBars)) {
            VaultStages(stage, phrase, introError, onBack, onStage = { stage = it }, onPhrase = { phrase = it }, onIntroError = { introError = it })
        }
        Row(Modifier.fillMaxWidth().navigationBarsPadding().padding(end = 16.dp, top = 4.dp, bottom = 10.dp), horizontalArrangement = Arrangement.End) {
            Box(
                Modifier.size(40.dp).clip(CircleShape).background(ROW).border(2.dp, YELLOW, CircleShape).clickable { help = true },
                contentAlignment = Alignment.Center
            ) { Text("?", color = YELLOW, fontSize = 20.sp, fontWeight = FontWeight.Bold) }
        }
    }
    if (help) VaultHelpOverlay(onClose = { help = false; AppSettings.vaultDemoSeen.set(true) })
}

@Composable
private fun VaultStages(
    stage: VaultStage, phrase: String, introError: String?, onBack: () -> Unit,
    onStage: (VaultStage) -> Unit, onPhrase: (String) -> Unit, onIntroError: (String?) -> Unit
) {
    val context = LocalContext.current
    when (stage) {
        VaultStage.INTRO -> VaultIntro(
            error = introError,
            onBack = onBack,
            onStart = {
                try {
                    onPhrase(VaultCrypto.generatePhrase(context))
                    onIntroError(null)
                    onStage(VaultStage.WORDS)
                } catch (e: Exception) {
                    onIntroError(e.message ?: "Nepodařilo se vytvořit slova")
                }
            }
        )
        VaultStage.WORDS -> VaultWords(phrase, onBack = { onPhrase(""); onStage(VaultStage.INTRO) }, onNext = { onStage(VaultStage.CHECK) })
        VaultStage.CHECK -> VaultCheck(phrase, onBack = { onStage(VaultStage.WORDS) }, onDone = { onPhrase(""); onStage(VaultStage.LIST) })
        VaultStage.LOCKED -> VaultLocked(onBack = onBack, onUnlocked = { onStage(VaultStage.LIST) })
        VaultStage.LIST -> VaultList(onBack = onBack, onLock = { VaultManager.lock(); onStage(VaultStage.LOCKED) })
    }
}

private class HelpStep(val icon: String, val title: String, val text: String)

private val HELP_STEPS = listOf(
    HelpStep("🔐", "Tohle je tvůj osobní trezor hesel", "Ukládáš si sem přihlášení k webům. Appka je pak umí sama vyplnit."),
    HelpStep("📝", "12 náhodně vylosovaných slov", "Při založení trezoru dostaneš 12 náhodných slov. Zapiš si je na papír – jsou jediným klíčem k trezoru. Bez nich se k heslům nedostane nikdo, ani ty."),
    HelpStep("🙈", "Tvoje hesla se ukládají pouze u tebe!", "Jsou zašifrovaná jen v tomto telefonu a nikam se neposílají. Já je vůbec nevidím!"),
    HelpStep("💾", "Záloha", "Nastavení → Export → zaškrtni „Trezor hesel“. V souboru je trezor zašifrovaný – bez tvých 12 slov ho nikdo nepřečte."),
    HelpStep("📲", "Obnova", "Na novém telefonu: Nastavení → Import, vyber soubor a zadej svých 12 slov. PIN nebo otisk si pak nastavíš znovu."),
    HelpStep("❓", "Nápověda je tu pořád", "Tuhle ukázku si kdykoli pustíš otazníkem vpravo dole.")
)

// Pruvodce trezorem: vlastni okno pres celou obrazovku (dotyky i tlacitko Zpet patri vzdy jemu - driv se na posledni
// strance obcas "zasekl" a reagovalo jen systemove Zpet). Karta se zlutym obrysem; samo dal po 6 s,
// sipky vlevo / vpravo = o krok zpet / dal, Preskocit a Hotovo = konec.
@Composable
private fun VaultHelpOverlay(onClose: () -> Unit) {
    var i by remember { mutableIntStateOf(0) }
    val last = HELP_STEPS.lastIndex
    var closed by remember { mutableStateOf(false) }
    fun close() { if (!closed) { closed = true; onClose() } }
    fun next() { if (i < last) i++ else close() }
    fun prev() { if (i > 0) i-- }
    LaunchedEffect(i) { delay(6000); if (i < last) i++ }
    var blinkOn by remember { mutableStateOf(true) }
    LaunchedEffect(i) { if (i == last) while (true) { delay(350); blinkOn = !blinkOn } }
    val step = HELP_STEPS[i]
    Dialog(
        onDismissRequest = { close() },
        properties = androidx.compose.ui.window.DialogProperties(usePlatformDefaultWidth = false, decorFitsSystemWindows = false)
    ) {
        Box(
            Modifier.fillMaxSize().background(Color(0xE0000000))
                .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { next() }
        ) {
            Column(
                Modifier.align(Alignment.Center).padding(horizontal = 28.dp).fillMaxWidth()
                    .clip(RoundedCornerShape(18.dp)).background(Color(0xFF242424))
                    .border(2.dp, YELLOW, RoundedCornerShape(18.dp)).padding(22.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text(step.icon, fontSize = 36.sp)
                Text(step.title, color = Color.White, fontSize = 19.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
                Text(step.text, color = Color(0xFFDDDDDD), fontSize = 15.sp, textAlign = TextAlign.Center)
                Text("${i + 1} / ${HELP_STEPS.size}", color = MUTED, fontSize = 12.sp)
            }
            Column(
                Modifier.align(Alignment.BottomCenter).navigationBarsPadding().padding(start = 24.dp, end = 24.dp, bottom = 70.dp).fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // sipky: o krok zpet / dal (uzivatel se muze vratit a precist si krok znovu)
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    @Composable
                    fun Arrow(right: Boolean, enabled: Boolean, onClick: () -> Unit) {
                        Box(
                            Modifier.weight(1f).height(46.dp).clip(RoundedCornerShape(14.dp)).background(ROW)
                                .border(1.dp, if (enabled) YELLOW else Color(0xFF3A3A3A), RoundedCornerShape(14.dp))
                                .clickable(enabled = enabled, onClick = onClick),
                            contentAlignment = Alignment.Center
                        ) {
                            androidx.compose.foundation.Image(
                                androidx.compose.ui.res.painterResource(com.example.actimelteambrowser.R.drawable.ic_nav_back), null,
                                modifier = Modifier.size(22.dp).then(if (right) Modifier.graphicsLayer { rotationZ = 180f } else Modifier),
                                colorFilter = androidx.compose.ui.graphics.ColorFilter.tint(if (enabled) YELLOW else Color(0xFF555555))
                            )
                        }
                    }
                    Arrow(false, i > 0) { prev() }
                    Arrow(true, i < last) { next() }
                }
                // Preskocit (cerveny obrys) a Dalsi / Hotovo (zlute)
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    Box(
                        Modifier.weight(1f).height(50.dp).clip(RoundedCornerShape(14.dp)).border(2.dp, Color(0xFFE53935), RoundedCornerShape(14.dp)).clickable { close() },
                        contentAlignment = Alignment.Center
                    ) { Text("Přeskočit", color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.Bold) }
                    Box(
                        Modifier.weight(1f).height(50.dp).clip(RoundedCornerShape(14.dp)).background(YELLOW).clickable { next() },
                        contentAlignment = Alignment.Center
                    ) { Text(if (i < last) "Další" else "Hotovo", color = Color(0xFF1A1A1A), fontSize = 15.sp, fontWeight = FontWeight.Bold) }
                }
            }
            // posledni krok: zluty blikajici krouzek kolem otazniku vpravo dole
            if (i == last && blinkOn) Box(
                Modifier.align(Alignment.BottomEnd).navigationBarsPadding().padding(end = 12.dp, bottom = 6.dp).size(48.dp)
                    .border(3.dp, YELLOW, CircleShape)
            )
        }
    }
}

/** Tlacitko, ktere se musi drzet [seconds] s: zleva doprava se plni zlute, text "x s / 5 s"; pusteni driv = zpet na 0. */
@Composable
private fun HoldButton(seconds: Int, onDone: () -> Unit) {
    val prog = remember { androidx.compose.animation.core.Animatable(0f) }
    val scope = rememberCoroutineScope()
    var done by remember { mutableStateOf(false) }
    val shown = (prog.value * seconds).toInt().coerceIn(0, seconds)
    Box(
        Modifier
            .padding(16.dp)
            .fillMaxWidth()
            .height(54.dp)
            .clip(RoundedCornerShape(16.dp))
            .background(ACCENT)
            .pointerInput(Unit) {
                awaitEachGesture {
                    awaitFirstDown()
                    val job = scope.launch {
                        prog.animateTo(1f, androidx.compose.animation.core.tween(((1f - prog.value) * seconds * 1000).toInt(), easing = androidx.compose.animation.core.LinearEasing))
                        if (!done) { done = true; onDone() }
                    }
                    waitForUpOrCancellation()
                    if (!done) {
                        job.cancel()
                        scope.launch { prog.animateTo(0f, androidx.compose.animation.core.tween(300)) }
                    }
                }
            },
        contentAlignment = Alignment.Center
    ) {
        // zluta vypln zleva doprava podle casu drzeni
        Box(Modifier.align(Alignment.CenterStart).fillMaxHeight().fillMaxWidth(prog.value).background(YELLOW))
        Text("$shown s / $seconds s", color = ON_ACCENT, fontSize = 16.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun VaultIntro(error: String?, onBack: () -> Unit, onStart: () -> Unit) {
    ScreenScaffold(title = "Trezor hesel", onBack = onBack) {
        Column(Modifier.verticalScroll(rememberScrollState()).padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text(
                "Hesla se ukládají jen v tomto telefonu a jsou zašifrovaná. Klíčem je 12 slov, která ti za chvíli ukážu. " +
                    "Opiš si je na papír. Bez nich se k heslům nedostane nikdo, ani ty.",
                color = Color(0xFFCCCCCC), fontSize = 15.sp
            )
            if (error != null) Text(error, color = Color(0xFFEF5350), fontSize = 14.sp)
            BigButton("Vytvořit trezor", ACCENT, ON_ACCENT, onClick = onStart)
            // co kdyz slova ztratim
            Column(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(Color(0xFF2A1414))
                    .border(1.dp, Color(0xFF7A2A2A), RoundedCornerShape(16.dp)).padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Text("⚠ Když 12 slov ztratíš nebo zapomeneš", color = Color(0xFFFF8A80), fontSize = 15.sp, fontWeight = FontWeight.Bold)
                Text(
                    "Bohužel se k tvému trezoru už nikdo nedostane – ani ty, ani já. Obnovit to nejde, protože klíč máš jen ty.",
                    color = Color(0xFFDDDDDD), fontSize = 14.sp
                )
            }
            // rozklikavaci otazka: kde jsou hesla a kdo je vidi
            var faq by remember { mutableStateOf(false) }
            Column(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(PANEL)
                    .clickable { faq = !faq }.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Kde jsou moje hesla a může je někdo vidět?", color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                    Text(if (faq) "▲" else "▼", color = YELLOW, fontSize = 14.sp)
                }
                if (faq) {
                    Text("📱  Jen v tomhle telefonu", color = YELLOW, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                    Text(
                        "Jméno a heslo, které si do trezoru uložíš, se zapíše jen do paměti tohoto telefonu – a to zašifrované. " +
                            "Klíč k šifře vzniká z tvých 12 slov. Bez nich jsou data jen nečitelná změť znaků.",
                        color = Color(0xFFDDDDDD), fontSize = 14.sp
                    )
                    Text("💾  Export = zašifrovaná záloha", color = YELLOW, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                    Text(
                        "Když dáš Nastavení → Export a zaškrtneš trezor, uloží se do souboru tvůj trezor zašifrovaný tvými 12 slovy. " +
                            "Samotná slova v souboru nejsou. Soubor si můžeš schovat kamkoli – kdo nezná slova, nic z něj nepřečte.",
                        color = Color(0xFFDDDDDD), fontSize = 14.sp
                    )
                    Text("📲  Import = trezor zpátky", color = YELLOW, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                    Text(
                        "Na novém telefonu dáš Import, vybereš soubor a zadáš svých 12 slov. Trezor se rozšifruje a máš ho zpátky. " +
                            "Pokud budeš soubor uchovávat, budeš mít trezor vždycky uložený u sebe.",
                        color = Color(0xFFDDDDDD), fontSize = 14.sp
                    )
                    Text("🚫  Žádný server", color = YELLOW, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                    Text(
                        "Tvoje údaje se nikdy – ani při exportu a importu – neposílají na žádný server. Nemám je, nevidím je, " +
                            "a proto je ani nemůžu zneužít já, ani nikdo jiný.",
                        color = Color(0xFFDDDDDD), fontSize = 14.sp
                    )
                }
            }
            Spacer(Modifier.height(16.dp))
        }
    }
}

@Composable
private fun VaultWords(phrase: String, onBack: () -> Unit, onNext: () -> Unit) {
    val words = phrase.split(" ")
    ScreenScaffold(title = "Tvých 12 slov", onBack = onBack) {
        Column(Modifier.verticalScroll(rememberScrollState()).padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text(
                "Opiš si je na papír ve správném pořadí. Nikde se neukládají a nejdou obnovit. Bez nich o hesla přijdeš.",
                color = MUTED, fontSize = 14.sp
            )
            for (i in words.indices step 2) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    for (k in i..minOf(i + 1, words.size - 1)) {
                        Text(
                            "${k + 1}. ${words[k]}", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold,
                            modifier = Modifier.weight(1f).clip(RoundedCornerShape(14.dp)).background(PANEL).padding(horizontal = 14.dp, vertical = 14.dp)
                        )
                    }
                }
            }
            Text(
                "Až budeš mít slova opsaná na papíře, podrž tlačítko 5 sekund.",
                color = Color(0xFFCCCCCC), fontSize = 14.sp, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth().padding(top = 8.dp)
            )
            HoldButton(5, onDone = onNext)
        }
    }
}

/** Zabrneni trezoru: 0,5 s - pauza 0,5 s - 0,5 s (vytvoreni trezoru a ulozeni hesla). */
internal fun vaultBuzz(context: Context) {
    if (!AppSettings.vibrationOn.get()) return
    val vib = if (Build.VERSION.SDK_INT >= 31)
        (context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? android.os.VibratorManager)?.defaultVibrator
    else @Suppress("DEPRECATION") (context.getSystemService(Context.VIBRATOR_SERVICE) as? android.os.Vibrator)
    vib ?: return
    val pattern = longArrayOf(0, 500, 500, 500)
    runCatching {
        if (Build.VERSION.SDK_INT >= 26) vib.vibrate(android.os.VibrationEffect.createWaveform(pattern, -1))
        else @Suppress("DEPRECATION") vib.vibrate(pattern, -1)
    }
}

// Kontrola: uzivatel zada 2 nahodna slova z papiru; po Dokoncit se trezor vytvori, zabrni a ukaze se info
@Composable
private fun VaultCheck(phrase: String, onBack: () -> Unit, onDone: () -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val words = phrase.split(" ")
    val picks = remember { (1..VaultCrypto.WORD_COUNT).shuffled().take(2).sorted() }
    val answers = remember { mutableStateListOf("", "") }
    var error by remember { mutableStateOf<String?>(null) }
    var busy by remember { mutableStateOf(false) }
    var created by remember { mutableStateOf(false) }
    ScreenScaffold(title = "Kontrola", onBack = onBack) {
        Column(Modifier.verticalScroll(rememberScrollState()).padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text("Napiš 2 slova z papíru", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
            for ((k, n) in picks.withIndex()) {
                OutlinedTextField(
                    value = answers[k],
                    onValueChange = { answers[k] = it; error = null },
                    label = { Text("Slovo č. $n") },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                    modifier = Modifier.fillMaxWidth()
                )
            }
            if (error != null) Text(error ?: "", color = Color(0xFFEF5350), fontSize = 14.sp)
            BigButton(if (busy) "Vytvářím trezor…" else "Dokončit", ACCENT, ON_ACCENT) {
                if (!busy && !created) {
                    val wrong = picks.withIndex().filter { (k, n) -> VaultCrypto.normalize(answers[k]) != words[n - 1] }.map { it.value }
                    if (wrong.isNotEmpty()) {
                        error = "Nesedí slovo č. ${wrong.joinToString(" a ")}, zkontroluj papír."
                    } else {
                        busy = true
                        scope.launch {
                            val ok = withContext(Dispatchers.Default) {
                                runCatching { VaultManager.create(context, phrase) }.isSuccess
                            }
                            busy = false
                            if (ok) { created = true; vaultBuzz(context) } else error = "Trezor se nepodařilo vytvořit."
                        }
                    }
                }
            }
        }
    }
    // po vytvoreni: info, ze takhle telefon zabrni i pri ulozeni hesla
    if (created) Dialog(onDismissRequest = { }) {
        Column(
            Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(Color(0xFF242424))
                .border(2.dp, ACCENT, RoundedCornerShape(20.dp)).padding(22.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Text("✅", fontSize = 34.sp)
            Text("Trezor je vytvořený", color = Color.White, fontSize = 19.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
            Text(
                "Cítil jsi to dvojí zabrnění? Přesně takhle telefon zabrní pokaždé, když si do trezoru uložíš nějaké heslo – " +
                    "poznáš tak, že je bezpečně uložené.",
                color = Color(0xFFDDDDDD), fontSize = 15.sp, textAlign = TextAlign.Center
            )
            Box(
                Modifier.fillMaxWidth().height(50.dp).clip(RoundedCornerShape(14.dp)).background(ACCENT).clickable { onDone() },
                contentAlignment = Alignment.Center
            ) { Text("Rozumím", color = ON_ACCENT, fontSize = 15.sp, fontWeight = FontWeight.Bold) }
        }
    }
}

@Composable
private fun VaultLocked(onBack: () -> Unit, onUnlocked: () -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var text by remember { mutableStateOf("") }
    var pin by remember { mutableStateOf("") }
    var usePin by remember { mutableStateOf(VaultManager.hasPin(context)) }
    var error by remember { mutableStateOf<String?>(null) }
    var busy by remember { mutableStateOf(false) }
    val activity = context as? Activity
    val hasBio = remember { Build.VERSION.SDK_INT >= 28 && VaultManager.hasBio(context) }
    // odemceni otiskem prstu (systemovy dialog); novy otisk v telefonu klic zneplatni
    fun startBio() {
        if (Build.VERSION.SDK_INT < 28 || activity == null) return
        val cipher = runCatching { VaultManager.bioUnlockCipher() }.getOrNull()
        if (cipher == null) {
            VaultManager.removeBio(context)
            error = "Otisk už neplatí, použij PIN nebo 12 slov."
            return
        }
        bioAuthenticate(
            activity, cipher, "Odemknout trezor",
            onOk = { c ->
                scope.launch {
                    val ok = withContext(Dispatchers.Default) { VaultManager.bioFinishUnlock(context, c) }
                    if (ok) onUnlocked() else error = "Odemknutí otiskem se nepovedlo."
                }
            },
            onFail = { msg -> if (msg.isNotEmpty()) error = msg }
        )
    }
    LaunchedEffect(Unit) { if (hasBio) startBio() }
    if (usePin) {
        ScreenScaffold(title = "Trezor hesel", onBack = onBack) {
            Column(Modifier.verticalScroll(rememberScrollState()).padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text("Trezor je zamčený. Zadej PIN.", color = Color(0xFFCCCCCC), fontSize = 15.sp)
                OutlinedTextField(
                    value = pin,
                    onValueChange = { pin = it.filter { c -> c.isDigit() }.take(8); error = null },
                    label = { Text("PIN") },
                    singleLine = true,
                    visualTransformation = PasswordVisualTransformation(),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                    modifier = Modifier.fillMaxWidth()
                )
                if (error != null) Text(error ?: "", color = Color(0xFFEF5350), fontSize = 14.sp)
                BigButton(if (busy) "Odemykám…" else "Odemknout PINem", ACCENT, ON_ACCENT) {
                    if (!busy && pin.length >= 4) {
                        busy = true
                        scope.launch {
                            val r = withContext(Dispatchers.Default) { VaultManager.unlockWithPin(context, pin) }
                            busy = false
                            pin = ""
                            when (r) {
                                PinResult.OK -> onUnlocked()
                                PinResult.WRONG -> error = "Špatný PIN. Zbývá pokusů: ${VaultManager.pinTriesLeft()}."
                                PinResult.TOO_MANY -> { usePin = false; error = "Příliš mnoho pokusů, PIN byl smazán. Zadej 12 slov." }
                            }
                        }
                    }
                }
                if (hasBio) BigButton("Odemknout otiskem prstu", ROW, Color.White) { startBio() }
                BigButton("Zadat 12 slov místo PINu", ROW, Color.White) { usePin = false; error = null }
            }
        }
        return
    }
    ScreenScaffold(title = "Trezor hesel", onBack = onBack) {
        Column(Modifier.verticalScroll(rememberScrollState()).padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text("Trezor je zamčený. Zadej svých 12 slov (oddělená mezerou).", color = Color(0xFFCCCCCC), fontSize = 15.sp)
            if (hasBio) BigButton("Odemknout otiskem prstu", ROW, Color.White) { startBio() }
            OutlinedTextField(
                value = text,
                onValueChange = { text = it; error = null },
                label = { Text("12 slov") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                modifier = Modifier.fillMaxWidth().heightIn(min = 120.dp)
            )
            if (error != null) Text(error ?: "", color = Color(0xFFEF5350), fontSize = 14.sp)
            BigButton(if (busy) "Odemykám…" else "Odemknout", ACCENT, ON_ACCENT) {
                if (!busy) {
                    val valid = runCatching { VaultCrypto.isValidPhrase(context, text) }.getOrDefault(false)
                    if (!valid) {
                        error = "Zadej přesně 12 slov ze seznamu."
                    } else {
                        busy = true
                        scope.launch {
                            val ok = withContext(Dispatchers.Default) { VaultManager.unlock(context, text) }
                            busy = false
                            if (ok) { text = ""; onUnlocked() } else error = "Tahle slova k trezoru nepatří."
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun VaultList(onBack: () -> Unit, onLock: () -> Unit) {
    var list by remember { mutableStateOf(VaultManager.all()) }
    var selected by remember { mutableStateOf<VaultEntry?>(null) }
    var editing by remember { mutableStateOf<VaultEntry?>(null) }
    var adding by remember { mutableStateOf(false) }
    var pinDialog by remember { mutableStateOf(false) }

    val audit = remember(list) { VaultManager.audit() }   // slaba / opakovana hesla

    // zpet: z upravy zpet do detailu / seznamu, z detailu do seznamu
    BackHandler(enabled = selected != null || editing != null || adding) {
        if (editing != null || adding) { editing = null; adding = false } else selected = null
    }

    val ed = editing
    val sel = selected
    when {
        adding || ed != null -> VaultEdit(
            entry = ed,
            onBack = { editing = null; adding = false },
            onSaved = { editing = null; adding = false; selected = null; list = VaultManager.all() }
        )
        sel != null -> VaultDetail(
            entry = sel,
            onBack = { selected = null },
            onEdit = { editing = sel },
            onDeleted = { selected = null; list = VaultManager.all() }
        )
        else -> ScreenScaffold(title = "Trezor hesel", onBack = onBack) {
            if (list.isEmpty()) {
                EmptyText("Zatím tu nejsou žádná hesla. Přidej první tlačítkem níže.")
            }
            if (audit.isNotEmpty()) {
                Text(
                    "⚠ Hesla k vylepšení: ${audit.size} (slabá nebo opakovaná). Zkus je změnit.",
                    color = Color(0xFFFFB74D), fontSize = 13.sp,
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp)
                )
            }
            LazyColumn(Modifier.weight(1f).padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                items(list, key = { it.id }) { e ->
                    Column(
                        Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(PANEL)
                            .clickable { selected = e }.padding(horizontal = 18.dp, vertical = 14.dp)
                    ) {
                        Text(e.domain, color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.Bold)
                        if (e.username.isNotEmpty()) Text(e.username, color = MUTED, fontSize = 13.sp)
                        audit[e.id]?.let { Text("⚠ $it heslo", color = Color(0xFFFFB74D), fontSize = 12.sp) }
                    }
                }
            }
            BigButton("+ Přidat přihlášení", ACCENT, ON_ACCENT) { adding = true }
            BigButton("Rychlé odemykání (PIN, otisk)", ROW, Color.White) { pinDialog = true }
            BigButton("Zamknout trezor", ROW, Color.White, onClick = onLock)
        }
    }
    if (pinDialog) VaultPinDialog(onDismiss = { pinDialog = false })
}

@Composable
private fun VaultField(label: String, value: String) {
    Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(PANEL).padding(horizontal = 16.dp, vertical = 12.dp)) {
        Text(label, color = MUTED, fontSize = 12.sp)
        Text(value, color = Color.White, fontSize = 16.sp)
    }
}

// Radek detailu: popisek + hodnota vlevo, ikony (oko, kopirovat) vpravo
@Composable
private fun VaultValueRow(label: String, value: String, actions: @Composable () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(PANEL).padding(start = 16.dp, end = 6.dp, top = 10.dp, bottom = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f)) {
            Text(label, color = MUTED, fontSize = 12.sp)
            Text(value, color = Color.White, fontSize = 16.sp)
        }
        actions()
    }
}

@Composable
private fun VaultIconButton(res: Int, desc: String, onClick: () -> Unit) {
    Box(
        Modifier.size(44.dp).clip(RoundedCornerShape(12.dp)).clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        androidx.compose.foundation.Image(
            androidx.compose.ui.res.painterResource(res), contentDescription = desc, modifier = Modifier.size(22.dp)
        )
    }
}

@Composable
private fun VaultDetail(entry: VaultEntry, onBack: () -> Unit, onEdit: () -> Unit, onDeleted: () -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var show by remember { mutableStateOf(false) }
    var confirm by remember { mutableStateOf(false) }
    ScreenScaffold(title = entry.domain, onBack = onBack) {
        Column(
            Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            // prihlasovaci jmeno + kopirovat
            VaultValueRow("Přihlašovací jméno", entry.username.ifEmpty { "—" }) {
                if (entry.username.isNotEmpty()) {
                    VaultIconButton(com.example.actimelteambrowser.R.drawable.ic_copy_url, "Kopírovat jméno") {
                        copySecret(context, entry.username)
                        com.example.actimelteambrowser.AppToast.show(context, "Jméno zkopírováno")
                    }
                }
            }
            // heslo + oko (zobrazit / skryt) + kopirovat
            VaultValueRow("Heslo", if (show) entry.password else "••••••••••") {
                VaultIconButton(
                    if (show) com.example.actimelteambrowser.R.drawable.ic_eye_off else com.example.actimelteambrowser.R.drawable.ic_eye,
                    if (show) "Skrýt heslo" else "Zobrazit heslo"
                ) { show = !show }
                VaultIconButton(com.example.actimelteambrowser.R.drawable.ic_copy_url, "Kopírovat heslo") {
                    copySecret(context, entry.password)
                    com.example.actimelteambrowser.AppToast.show(context, "Heslo zkopírováno (schránka se za minutu vymaže)")
                }
            }
            if (entry.note.isNotEmpty()) VaultField("Poznámka", entry.note)
            Spacer(Modifier.height(8.dp))
            Text("Smazat toto přihlášení", color = Color(0xFFEF5350), fontSize = 13.sp,
                modifier = Modifier.clip(RoundedCornerShape(10.dp)).clickable { confirm = true }.padding(8.dp))
        }
        // dole: Upravit (prepsat a ulozit) + Zpet
        Row(Modifier.fillMaxWidth().padding(16.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Box(
                Modifier.weight(1f).height(52.dp).clip(RoundedCornerShape(16.dp)).background(ROW).clickable(onClick = onBack),
                contentAlignment = Alignment.Center
            ) { Text("Zpět", color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.Bold) }
            Box(
                Modifier.weight(1f).height(52.dp).clip(RoundedCornerShape(16.dp)).background(ACCENT).clickable(onClick = onEdit),
                contentAlignment = Alignment.Center
            ) { Text("Upravit", color = ON_ACCENT, fontSize = 15.sp, fontWeight = FontWeight.Bold) }
        }
    }
    if (confirm) {
        ConfirmDialog(
            title = "Smazat heslo?",
            text = entry.domain,
            noLabel = "Zrušit",
            yesLabel = "Smazat",
            onNo = { confirm = false },
            onYes = {
                confirm = false
                scope.launch {
                    withContext(Dispatchers.IO) { runCatching { VaultManager.remove(context, entry.id) } }
                    onDeleted()
                }
            }
        )
    }
}

// Z adresy nechat jen domenu (seznam.cz), bez https:// , cesty a "www."
private fun cleanDomain(s: String): String =
    s.trim().lowercase().removePrefix("https://").removePrefix("http://").substringBefore('/').substringBefore('?').removePrefix("www.")

@Composable
private fun VaultEdit(entry: VaultEntry?, onBack: () -> Unit, onSaved: () -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var domain by remember { mutableStateOf(entry?.domain ?: "") }
    var username by remember { mutableStateOf(entry?.username ?: "") }
    var password by remember { mutableStateOf(entry?.password ?: "") }
    var note by remember { mutableStateOf(entry?.note ?: "") }
    var show by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    ScreenScaffold(title = if (entry == null) "Přidat přihlášení" else "Upravit přihlášení", onBack = onBack) {
        Column(Modifier.verticalScroll(rememberScrollState()).padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            OutlinedTextField(
                value = domain, onValueChange = { domain = it; error = null },
                label = { Text("Web (např. seznam.cz)") }, singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Uri),
                modifier = Modifier.fillMaxWidth()
            )
            OutlinedTextField(
                value = username, onValueChange = { username = it },
                label = { Text("Jméno / e-mail") }, singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email),
                modifier = Modifier.fillMaxWidth()
            )
            OutlinedTextField(
                value = password, onValueChange = { password = it; error = null },
                label = { Text("Heslo") }, singleLine = true,
                visualTransformation = if (show) VisualTransformation.None else PasswordVisualTransformation(),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                trailingIcon = {
                    VaultIconButton(
                        if (show) com.example.actimelteambrowser.R.drawable.ic_eye_off else com.example.actimelteambrowser.R.drawable.ic_eye,
                        if (show) "Skrýt heslo" else "Zobrazit heslo"
                    ) { show = !show }
                },
                modifier = Modifier.fillMaxWidth()
            )
            VaultSmallButton("Vygenerovat heslo", Modifier.fillMaxWidth()) { password = VaultCrypto.generatePassword(); show = true; error = null }
            OutlinedTextField(
                value = note, onValueChange = { note = it },
                label = { Text("Poznámka") },
                modifier = Modifier.fillMaxWidth()
            )
            if (error != null) Text(error ?: "", color = Color(0xFFEF5350), fontSize = 14.sp)
            BigButton("Uložit", ACCENT, ON_ACCENT) {
                val d = cleanDomain(domain)
                if (d.isEmpty() || password.isEmpty()) {
                    error = "Vyplň web a heslo."
                } else {
                    scope.launch {
                        val ok = withContext(Dispatchers.IO) {
                            runCatching {
                                if (entry == null) VaultManager.save(context, d, username.trim(), password, note)
                                else VaultManager.update(context, entry.copy(domain = d, username = username.trim(), password = password, note = note))
                            }.isSuccess
                        }
                        if (ok) { vaultBuzz(context); onSaved() } else error = "Uložení se nepovedlo (je trezor odemčený?)."
                    }
                }
            }
            BigButton("Zpět", ROW, Color.White, onClick = onBack)
        }
    }
}

@Composable
private fun VaultSmallButton(text: String, modifier: Modifier, onClick: () -> Unit) {
    Box(
        modifier.height(44.dp).clip(RoundedCornerShape(14.dp)).background(ROW).clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) { Text(text, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold) }
}

// Zkopiruje text oznaceny jako citlivy (Android 13+ ho neukazuje v nahledu schranky); po minute se schranka vycisti
private fun copySecret(context: Context, text: String) {
    val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
    val clip = ClipData.newPlainText("trezor", text)
    if (Build.VERSION.SDK_INT >= 24) {
        clip.description.extras = PersistableBundle().apply { putBoolean("android.content.extra.IS_SENSITIVE", true) }
    }
    cm.setPrimaryClip(clip)
    Handler(Looper.getMainLooper()).postDelayed({
        runCatching {
            val now = cm.primaryClip?.getItemAt(0)?.text?.toString()
            if (now == text) {
                if (Build.VERSION.SDK_INT >= 28) cm.clearPrimaryClip() else cm.setPrimaryClip(ClipData.newPlainText("", ""))
            }
        }
    }, 60_000)
}

/** Import: soubor obsahuje trezor, zadej 12 slov. Zasifrovane hesla se obnovi (nahradi stavajici trezor). */
@Composable
fun VaultRestoreDialog(backup: VaultBackup, onResult: (String) -> Unit, onDismiss: () -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var text by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }
    var busy by remember { mutableStateOf(false) }
    Dialog(onDismissRequest = { if (!busy) onDismiss() }) {
        Column(Modifier.clip(RoundedCornerShape(24.dp)).background(PANEL).padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text("Trezor hesel", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
            Text("V souboru je zašifrovaný trezor. Zadej svých 12 slov. Stávající trezor v tomto telefonu se nahradí.", color = MUTED, fontSize = 13.sp)
            OutlinedTextField(
                value = text, onValueChange = { text = it; error = null },
                label = { Text("12 slov") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                modifier = Modifier.fillMaxWidth().heightIn(min = 110.dp)
            )
            if (error != null) Text(error ?: "", color = Color(0xFFEF5350), fontSize = 13.sp)
            Spacer(Modifier.height(2.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp, Alignment.End)) {
                Text(
                    "Zrušit", color = Color(0xFFCCCCCC), fontSize = 14.sp, fontWeight = FontWeight.Bold,
                    modifier = Modifier.clip(RoundedCornerShape(14.dp)).background(ROW).clickable { if (!busy) onDismiss() }
                        .padding(horizontal = 18.dp, vertical = 10.dp)
                )
                Text(
                    if (busy) "Obnovuji…" else "Obnovit", color = ON_ACCENT, fontSize = 14.sp, fontWeight = FontWeight.Bold,
                    modifier = Modifier.clip(RoundedCornerShape(14.dp)).background(ACCENT).clickable {
                        if (!busy) {
                            busy = true
                            scope.launch {
                                val n = withContext(Dispatchers.Default) { VaultManager.restore(context, text, backup) }
                                busy = false
                                if (n >= 0) onResult("Trezor obnoven: $n hesel") else error = "Tahle slova k souboru nepatří."
                            }
                        }
                    }.padding(horizontal = 18.dp, vertical = 10.dp)
                )
            }
        }
    }
}

/** Nastaveni PINu (4-8 cislic): odemkne trezor v tomto telefonu bez 12 slov; po 5 spatnych pokusech se smaze. */
@Composable
private fun VaultPinDialog(onDismiss: () -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val has = remember { VaultManager.hasPin(context) }
    var pin by remember { mutableStateOf("") }
    var pin2 by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }
    var busy by remember { mutableStateOf(false) }
    var bioOn by remember { mutableStateOf(VaultManager.hasBio(context)) }
    Dialog(onDismissRequest = { if (!busy) onDismiss() }) {
        Column(Modifier.clip(RoundedCornerShape(24.dp)).background(PANEL).verticalScroll(rememberScrollState()).padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text("Rychlé odemykání", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
            if (Build.VERSION.SDK_INT >= 28) {
                Text(
                    if (bioOn) "Vypnout otisk prstu" else "Zapnout otisk prstu", color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Bold,
                    modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(ROW).clickable {
                        if (bioOn) {
                            VaultManager.removeBio(context)
                            bioOn = false
                            AppToast.show(context, "Otisk vypnut")
                        } else {
                            val act = context as? Activity
                            val cipher = runCatching { VaultManager.bioEnableCipher() }.getOrNull()
                            if (act == null || cipher == null) {
                                error = "V telefonu není nastavený otisk prstu."
                            } else {
                                bioAuthenticate(
                                    act, cipher, "Zapnout odemykání otiskem",
                                    onOk = { c ->
                                        scope.launch {
                                            val ok = withContext(Dispatchers.Default) { runCatching { VaultManager.bioFinishEnable(context, c) }.isSuccess }
                                            if (ok) { bioOn = true; AppToast.show(context, "Otisk zapnut") } else error = "Zapnutí se nepovedlo."
                                        }
                                    },
                                    onFail = { m -> if (m.isNotEmpty()) error = m }
                                )
                            }
                        }
                    }.padding(horizontal = 18.dp, vertical = 12.dp)
                )
            }
            Text(if (has) "Změnit PIN" else "Nastavit PIN", color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold)
            Text("PIN (4 až 8 číslic) odemkne trezor jen v tomto telefonu. Po 5 špatných pokusech se smaže a bude potřeba 12 slov.", color = MUTED, fontSize = 13.sp)
            OutlinedTextField(
                value = pin, onValueChange = { pin = it.filter { c -> c.isDigit() }.take(8); error = null },
                label = { Text("PIN") }, singleLine = true,
                visualTransformation = PasswordVisualTransformation(),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                modifier = Modifier.fillMaxWidth()
            )
            OutlinedTextField(
                value = pin2, onValueChange = { pin2 = it.filter { c -> c.isDigit() }.take(8); error = null },
                label = { Text("PIN znovu") }, singleLine = true,
                visualTransformation = PasswordVisualTransformation(),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                modifier = Modifier.fillMaxWidth()
            )
            if (error != null) Text(error ?: "", color = Color(0xFFEF5350), fontSize = 13.sp)
            if (has) {
                Text(
                    "Zrušit PIN", color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Bold,
                    modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(DANGER).clickable {
                        VaultManager.removePin(context)
                        AppToast.show(context, "PIN zrušen")
                        onDismiss()
                    }.padding(horizontal = 18.dp, vertical = 10.dp)
                )
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp, Alignment.End)) {
                Text(
                    "Zrušit", color = Color(0xFFCCCCCC), fontSize = 14.sp, fontWeight = FontWeight.Bold,
                    modifier = Modifier.clip(RoundedCornerShape(14.dp)).background(ROW).clickable { if (!busy) onDismiss() }
                        .padding(horizontal = 18.dp, vertical = 10.dp)
                )
                Text(
                    if (busy) "Ukládám…" else "Uložit", color = ON_ACCENT, fontSize = 14.sp, fontWeight = FontWeight.Bold,
                    modifier = Modifier.clip(RoundedCornerShape(14.dp)).background(ACCENT).clickable {
                        if (!busy) {
                            if (pin.isEmpty() && pin2.isEmpty()) {
                                onDismiss()   // PIN se nemeni (treba jen zapnuty otisk)
                            } else if (pin.length < 4) {
                                error = "PIN musí mít aspoň 4 číslice."
                            } else if (pin != pin2) {
                                error = "PINy se neshodují."
                            } else {
                                busy = true
                                scope.launch {
                                    val ok = withContext(Dispatchers.Default) {
                                        runCatching { VaultManager.setPin(context, pin) }.isSuccess
                                    }
                                    busy = false
                                    if (ok) { AppToast.show(context, "PIN nastaven"); onDismiss() } else error = "PIN se nepodařilo nastavit."
                                }
                            }
                        }
                    }.padding(horizontal = 18.dp, vertical = 10.dp)
                )
            }
        }
    }
}

// Systemovy dialog otisku prstu (Android 9+) navazany na sifru z Keystore; onFail("") = uzivatel zrusil
@RequiresApi(28)
private fun bioAuthenticate(activity: Activity, cipher: Cipher, title: String, onOk: (Cipher) -> Unit, onFail: (String) -> Unit) {
    val executor = activity.mainExecutor
    val prompt = android.hardware.biometrics.BiometricPrompt.Builder(activity)
        .setTitle(title)
        .setNegativeButton("Zrušit", executor) { _, _ -> onFail("") }
        .build()
    prompt.authenticate(
        android.hardware.biometrics.BiometricPrompt.CryptoObject(cipher),
        android.os.CancellationSignal(),
        executor,
        object : android.hardware.biometrics.BiometricPrompt.AuthenticationCallback() {
            override fun onAuthenticationSucceeded(result: android.hardware.biometrics.BiometricPrompt.AuthenticationResult) {
                val c = result.cryptoObject?.cipher
                if (c != null) onOk(c) else onFail("Ověření se nepovedlo.")
            }
            override fun onAuthenticationError(errorCode: Int, errString: CharSequence?) {
                onFail(errString?.toString() ?: "")
            }
        }
    )
}
