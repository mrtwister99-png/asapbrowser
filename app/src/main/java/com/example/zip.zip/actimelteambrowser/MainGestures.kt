package com.example.actimelteambrowser

import android.view.View
import androidx.core.graphics.toColorInt
import kotlin.math.roundToInt
import androidx.core.view.*
import com.example.actimelteambrowser.core.settings.AppSettings
import androidx.compose.ui.platform.ComposeView
import com.example.actimelteambrowser.core.settings.Gestures
import com.example.actimelteambrowser.core.gestures.gestureTick
import com.example.actimelteambrowser.ui.GestureOverlay
import com.example.actimelteambrowser.ui.GestureArea
import com.example.actimelteambrowser.ui.GestureAreaEditor
import com.example.actimelteambrowser.ui.GesturePanel
import com.example.actimelteambrowser.ui.GestureLook
import androidx.constraintlayout.widget.ConstraintLayout
import com.example.actimelteambrowser.core.settings.ButtonFunction
import android.view.ViewGroup

// Gesta: plocha, kulička a konfigurační mód gest (rozšíření MainActivity).

// Horni hranice plochy v editoru = vyska zavreneho panelu gest (px v plose pod status barem)
internal val gestAreaTopLimit = androidx.compose.runtime.mutableIntStateOf(0)
internal fun MainActivity.enterGestureConfig() {
    if (gestureConfigMode) return
    if (configMode) exitConfigMode()
    gestureConfigMode = true
    com.example.actimelteambrowser.core.settings.RewardGuard.setBlocked(totalBlocked.get())   // aktualni pocet zablokovanych reklam (cena Ctverecku v panelu)
    setChromeHidden(false)
    hideKeyboard()
    etSearchMain.clearFocus()
    etTopUrl.clearFocus()
    if (leftBarOpen) closeLeftBarAndHide()
    hideTabs()
    val parent = root as ViewGroup

    // pozadi: prechod cerna -> tmave seda se tremi UFO (nad webem, pod tlacitky a listami)
    gestBackdrop = addSetupBackdrop(7, false)

    // pruhledna vrstva: pohlti klepnuti do webu, list a tlacitek; v TESTu pusti dal jen dotyk na kulicku gest
    val scrim = View(this)
    scrim.isClickable = true
    scrim.setOnTouchListener { _, ev -> gestureTestMode && gestureTestTouch(ev) }
    scrim.elevation = dp(30).toFloat()   // nad listami i pruhy karet (20), pod plochou gest (35): vse je videt, ale neklika se na to
    val slp = ConstraintLayout.LayoutParams(0, 0)
    slp.topToTop = ConstraintLayout.LayoutParams.PARENT_ID
    slp.bottomToBottom = ConstraintLayout.LayoutParams.PARENT_ID
    slp.startToStart = ConstraintLayout.LayoutParams.PARENT_ID
    slp.endToEnd = ConstraintLayout.LayoutParams.PARENT_ID
    parent.addView(scrim, slp)
    gestScrim = scrim

    showGestureEditor()

    // panel shora
    val panel = ComposeView(this)
    panel.setContent {
        GesturePanel(
            onChanged = { gestTick.intValue += 1; orbView?.invalidate() },
            onResetArea = {
                AppSettings.gestureRect.reset()
                AppSettings.gestureSize.reset()
                gestResetKey.intValue += 1
            },
            onClose = { exitGestureConfig() },
            onPreviewStyle = { gestPreviewStyle.value = it; orbView?.styleOverride = it; orbView?.invalidate() },
            onAlignArea = { alignGestureAreaToOrb() },
            testMode = gestTestState.value,
            onTest = { setGestureTest(it) }
        )
    }
    panel.elevation = dp(45).toFloat()
    val plp = ConstraintLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT)
    plp.topToTop = ConstraintLayout.LayoutParams.PARENT_ID
    plp.startToStart = ConstraintLayout.LayoutParams.PARENT_ID
    plp.endToEnd = ConstraintLayout.LayoutParams.PARENT_ID
    panel.visibility = View.INVISIBLE
    parent.addView(panel, plp)
    gestPanel = panel
    panel.post {
        // panel je na zacatku zavreny: jeho vyska = horni hranice plochy gest
        gestAreaTopLimit.intValue = (panel.height - lastSystemTopPx).coerceAtLeast(0)
        panel.translationY = -panel.height.toFloat()
        panel.visibility = View.VISIBLE
        panel.animate().translationY(0f).setDuration(280).start()
    }
    for (n in listOf(5, 6) + extraViews.keys) buttonView(n)?.let { applySideMode(n, it) }   // bocni tlacitka celá
    updateOrbTarget()   // kulicka (start gesta) je v konfiguraci videt vzdy
    orbView?.alwaysShow = true              // editor schova vsechna tlacitka, kulicka (tlacitko gest) ale musi zustat videt
    orbView?.forwardTouch = false           // v nastaveni gest kulicka plochu neotevira
    orbView?.elevation = dp(40).toFloat()   // nad editorem plochy (35), aby tlacitko gest bylo dobre videt a plochu sla zarovnat
    if (gestureButtonN() == 0) AppToast.show(this, "Tlačítko Gesta není přiřazené, kulička ukazuje výchozí místo (tlačítko 6)", true)
    applyGestureConfigUi()
}

// Editor plochy gest (pouziva stejny ComposeView jako samotna plocha gest)
private fun MainActivity.showGestureEditor() {
    val density = resources.displayMetrics.density
    val bottomDp = ((bottomBar.height - lastSystemBottom) / density).toInt() + 16
    gestureView.setContent {
        @Suppress("UNUSED_VARIABLE", "unused") val tick = gestTick.intValue
        GestureAreaEditor(
            style = gestPreviewStyle.value ?: GestureLook.style(),
            topLimitPx = gestAreaTopLimit.intValue,
            bottomLimitPx = (bottomBar.height - lastSystemBottom).coerceAtLeast(0),
            defaultSizeDp = AppSettings.gestureSize.get().coerceIn(180, 340),
            bottomOffsetDp = bottomDp,
            resetKey = gestResetKey.intValue,
            onChange = { AppSettings.gestureRect.set(GestureArea.format(it)) },
            theme = GestureLook.theme(gestPreviewStyle.value ?: GestureLook.style())
        )
    }
    gestureView.visibility = View.VISIBLE
}

/**
 * TEST v nastaveni gest: panel i pozadi zmizi, plocha vypada jako pri beznem pouzivani (horni a spodni lista, bocni
 * tlacitka zasunuta) a z kulicky jde zkouset gesta - rozpoznane gesto se jen ohlasi, funkce se neprovede.
 * Zpet do nastaveni vraci zelene OK (nebo tlacitko Zpet).
 */
internal fun MainActivity.setGestureTest(on: Boolean) {
    if (!gestureConfigMode || gestureTestMode == on) return
    gestTestState.value = on
    testTouchActive = false
    hideGestures()   // zavre editor / zkousenou plochu
    if (on) {
        gestBackdrop?.visibility = View.GONE
        for ((v, vis) in gestHidden) v.visibility = vis
        gestHidden.clear()
    } else {
        gestBackdrop?.visibility = View.VISIBLE
        showGestureEditor()
        applyGestureConfigUi()
    }
    for (n in listOf(5, 6) + extraViews.keys) buttonView(n)?.let { applySideMode(n, it) }
    updateOrbTarget()
}

private var testTouchActive = false

// Dotyk v TESTu: zacne-li na kulicce gest, otevre plochu a pokracuje na ni jednim tahem (jako pri beznem pouzivani)
private fun MainActivity.gestureTestTouch(ev: android.view.MotionEvent): Boolean {
    val wl = IntArray(2)
    window.decorView.getLocationOnScreen(wl)
    val x = ev.rawX - wl[0]
    val y = ev.rawY - wl[1]
    when (ev.actionMasked) {
        android.view.MotionEvent.ACTION_DOWN -> {
            val orb = orbView
            val ol = IntArray(2)
            orb?.getLocationInWindow(ol)
            testTouchActive = orb != null && orb.isShown &&
                x >= ol[0] && x <= ol[0] + orb.width && y >= ol[1] && y <= ol[1] + orb.height
            if (testTouchActive) {
                val down = com.example.actimelteambrowser.ui.ExternalTouch(x, y, 0, ++extSeq)
                externalDown = down
                if (!gestureView.isVisible) showGestures(test = true)
                externalTouch.value = down
            }
        }
        android.view.MotionEvent.ACTION_MOVE ->
            if (testTouchActive) externalTouch.value = com.example.actimelteambrowser.ui.ExternalTouch(x, y, 1, ++extSeq)
        android.view.MotionEvent.ACTION_UP, android.view.MotionEvent.ACTION_CANCEL -> if (testTouchActive) {
            externalTouch.value = com.example.actimelteambrowser.ui.ExternalTouch(x, y, 2, ++extSeq)
            testTouchActive = false
        }
    }
    return true
}

// Skryje vse krome weboveho obsahu, kulicky gest, plochy a panelu (vola se i po onResume, ktery tlacitka obnovi)
internal fun MainActivity.applyGestureConfigUi() {
    val parent = root as ViewGroup
    val webTop = run {
        var v: View = webContainer
        var top: View = webContainer
        while (v.parent != null && v.parent !== parent) { v = v.parent as View; top = v }
        top
    }
    for (i in 0 until parent.childCount) {
        val c = parent.getChildAt(i)
        // spodni lista s tlacitky zustava videt (plocha gest do ni nesmi)
        if (c === gestScrim || c === gestBackdrop || c === gestPanel || c === gestureView || c === orbView || c === webTop || c === bottomBar) continue
        if (c.isVisible) {
            gestHidden[c] = View.VISIBLE
            c.visibility = View.INVISIBLE
        }
    }
}

internal fun MainActivity.exitGestureConfig() {
    if (!gestureConfigMode) return
    gestureConfigMode = false
    gestTestState.value = false
    testTouchActive = false
    val parent = root as ViewGroup
    gestBackdrop?.let { parent.removeView(it) }
    gestBackdrop = null
    gestPanel?.let { p ->
        p.animate().translationY(-p.height.toFloat()).setDuration(220).withEndAction { parent.removeView(p) }.start()
    }
    gestPanel = null
    gestScrim?.let { parent.removeView(it) }
    gestScrim = null
    gestPreviewStyle.value = null   // zamceny vzor se neuklada
    orbView?.styleOverride = null
    orbView?.invalidate()
    orbView?.elevation = dp(20).toFloat()
    orbView?.alwaysShow = false
    orbView?.forwardTouch = true
    for ((v, vis) in gestHidden) v.visibility = vis
    gestHidden.clear()
    hideGestures()   // zavre editor (ComposeView plochy)
    rebuildExtraButtons()
    wireButtons()
    updateButtonVisuals()
    AppToast.show(this, "Nastavení gest uloženo")
}

// Otevre pruhlednou plochu pro gesta (vychozi vpravo dole, 9 je u tlacitka 6; poloha a velikost podle nastaveni)
// demoBounds != null = ukazka: plocha nic neprovede ani nezavre, jen hlasi svou polohu (x, y, sirka, vyska v px)
// test = zkouseni v nastaveni gest: rozpoznane gesto se jen ohlasi (funkce se neprovede)
internal fun MainActivity.showGestures(test: Boolean = false, demoBounds: ((Float, Float, Float, Float) -> Unit)? = null) {
    hideKeyboard()
    etSearchMain.clearFocus()
    etTopUrl.clearFocus()
    val list = Gestures.load()
    // Ctverecky / Hvezdicky jen kdyz jsou odemcene (napr. import cizeho nastaveni je neodemkne)
    val style = GestureLook.style()
    val size = AppSettings.gestureSize.get().coerceIn(180, 340)
    val density = resources.displayMetrics.density
    val bottomDp = ((bottomBar.height - lastSystemBottom) / density).toInt() + 16
    // napoveda gest zacina pod hornim polem (a listou karet); schovane listy = hned nahore
    val topDp = if (topBar.translationY < 0f) 8 else ((topBar.height - lastSystemTopPx + stripTopPx) / density).toInt() + 6
    val theme = GestureLook.theme()
    gestureView.setContent {
        GestureOverlay(
            style = style,
            sizeDp = size,
            gestures = list,
            bottomOffsetDp = bottomDp,
            rect = GestureArea.parse(AppSettings.gestureRect.get()),
            onDismiss = { if (demoBounds == null) hideGestures() },
            onMatch = { def ->
                if (demoBounds == null) {
                    // vibrace pri rozpoznanem gestu
                    gestureTick(this)
                    hideGestures()
                    if (test) AppToast.show(this, "Gesto funguje: ${def.fn.label}", false, AppToast.Kind.OK)
                    else performFunction(def.fn)
                }
            },
            external = externalTouch.value,
            externalDown = externalDown,
            onUnknown = { if (demoBounds == null) AppToast.show(this, "Neznámé gesto") },
            onSurfaceBounds = demoBounds,
            showHints = demoBounds == null,
            theme = theme,
            topInsetDp = topDp,
            onMatchAt = { x, y -> if (demoBounds == null) showFirework(x, y) }
        )
    }
    gestureView.visibility = View.VISIBLE
}

internal fun MainActivity.hideGestures() {
    externalTouch.value = null
    externalDown = null
    gestureView.visibility = View.GONE
    gestureView.disposeComposition()
}

// Cislo tlacitka, ktere ma funkci Gesta (klepnuti) = tam je kulicka; 0 = nikde. 7 a 8 nejsou povolena.
internal fun MainActivity.gestureButtonN(): Int {
    for (n in listOf(1, 2, 3, 4, 5, 6, 9, 10, 11, 12)) {
        if (AppSettings.isEnabled(n) && buttonView(n) != null && buttonFunction(n, false) == ButtonFunction.GESTURES) return n
    }
    return 0
}

// Kulicka se presune na tlacitko s funkci Gesta; samotne tlacitko se zneviditelni (zustava klikaci/dotykove)
internal fun MainActivity.updateOrbTarget() {
    val g = gestureButtonN()
    for (n in 1..12) {
        val v = buttonView(n) ?: continue
        if (n != g && v.alpha == 0f) v.alpha = 1f
    }
    val orb = orbView ?: return
    if (g == 0) {
        // v konfiguraci gest je kulicka videt vzdy, i kdyz zadne tlacitko nema funkci Gesta: ukazuje, kde gesto zacina
        val b6 = buttonView(6)
        if (gestureConfigMode && b6 != null) {
            if (b6.isGone) b6.visibility = View.INVISIBLE   // jinak by nemelo polohu
            orb.target = b6
            orb.visibility = View.VISIBLE
            return
        }
        orb.visibility = View.GONE
        return
    }
    val tv = buttonView(g) ?: return
    tv.alpha = 0f
    orb.target = tv
    orb.visibility = View.VISIBLE
}

// Kulicka pod tlacitkem Gest (bile kolecko + zelena tecka)
internal fun MainActivity.setupGestureOrb() {
    if (orbView != null) return
    val btn6 = findViewById<View>(R.id.btnSideRightMain)
    val orb = GestureOrbView(this, btn6)
    orb.elevation = dp(20).toFloat()   // nad spodni listou i bocnimi tlacitky; dotyky nechyta
    // vlevo nahore v rodici; presnou polohu na tlacitku si orb pocita sam (sleduje cilove tlacitko)
    val lp = ConstraintLayout.LayoutParams(dp(56), dp(56))
    lp.topToTop = ConstraintLayout.LayoutParams.PARENT_ID
    lp.startToStart = ConstraintLayout.LayoutParams.PARENT_ID
    (root as ViewGroup).addView(orb, lp)
    orbView = orb
}

// Zarovnat k tlacitku: plocha se prisune tak, aby startovni klavesa (9 vpravo dole, u tlacitek vlevo 7) lezela na kulicce tlacitka gest; velikost zustava
internal fun MainActivity.alignGestureAreaToOrb() {
    val orb = orbView ?: return
    val w = gestureView.width.toFloat()
    val h = gestureView.height.toFloat()
    if (w <= 0f || h <= 0f) return
    val gl = IntArray(2)
    val tl = IntArray(2)
    gestureView.getLocationInWindow(gl)
    orb.target.getLocationInWindow(tl)
    val cx = tl[0] - gl[0] + orb.target.width / 2f
    val cy = tl[1] - gl[1] + orb.target.height / 2f
    val density = resources.displayMetrics.density
    val cur = GestureArea.parse(AppSettings.gestureRect.get())
    val aw: Float
    val ah: Float
    if (cur != null) {
        aw = (cur.r - cur.l) / 1000f * w
        ah = (cur.b - cur.t) / 1000f * h
    } else {
        aw = AppSettings.gestureSize.get().coerceIn(180, 340) * density
        ah = aw
    }
    // tlacitko vlevo (start 7): klavesa 7 (vlevo dole) lezi na kulicce; jinak klavesa 9 (vpravo dole)
    val left = if (Gestures.startKey() == 7) (cx - aw / 6f).coerceIn(0f, w - aw) else ((cx + aw / 6f).coerceIn(aw, w) - aw)
    val bottom = (cy + ah / 6f).coerceIn(ah, h)
    val rect = com.example.actimelteambrowser.ui.GestureRect(
        (left / w * 1000f).roundToInt(), ((bottom - ah) / h * 1000f).roundToInt(),
        ((left + aw) / w * 1000f).roundToInt(), (bottom / h * 1000f).roundToInt()
    )
    AppSettings.gestureRect.set(GestureArea.format(rect))
    gestResetKey.intValue += 1   // editor nacte novou polohu
}
