package com.example.actimelteambrowser.ui

import androidx.activity.compose.BackHandler
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.runtime.State
import androidx.compose.runtime.derivedStateOf
import androidx.compose.ui.graphics.drawscope.DrawScope
import com.example.actimelteambrowser.R
import androidx.compose.foundation.background
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.material3.Slider
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.positionInWindow
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalView
import android.os.Build
import android.view.HapticFeedbackConstants
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.actimelteambrowser.core.settings.GestureDef
import com.example.actimelteambrowser.core.gestures.gestureTick
import com.example.actimelteambrowser.core.settings.Gestures
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGesturesAfterLongPress
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.DisposableEffect
import android.media.AudioAttributes
import android.media.MediaPlayer
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.zIndex
import kotlinx.coroutines.delay
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.offset
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.input.pointer.positionChange
import androidx.compose.ui.unit.IntOffset
import kotlin.math.roundToInt
import com.example.actimelteambrowser.core.settings.SearchEngines
import androidx.compose.foundation.Image
import androidx.compose.runtime.produceState
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.actimelteambrowser.core.settings.AppSettings
import com.example.actimelteambrowser.core.settings.ButtonDefaults
import com.example.actimelteambrowser.core.settings.ButtonFunction
import com.example.actimelteambrowser.data.BookmarkFolder
import com.example.actimelteambrowser.data.Bookmark
import com.example.actimelteambrowser.data.BookmarksRepository
import com.example.actimelteambrowser.data.FolderWithCount
import com.example.actimelteambrowser.data.HistoryRepository
import com.example.actimelteambrowser.data.HistoryVisit
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale


// Nastavení → O aplikaci.

// ---------------------------------------------------------------- O APLIKACI

// Verze z manifestu/gradle (versionName a versionCode)
@Suppress("DEPRECATION")
internal fun appVersionText(ctx: android.content.Context): String = try {
    val pi = ctx.packageManager.getPackageInfo(ctx.packageName, 0)
    val code = if (Build.VERSION.SDK_INT >= 28) pi.longVersionCode else pi.versionCode.toLong()
    "Verze ${pi.versionName} (build $code)"
} catch (e: Exception) {
    "Verze neznámá"
}

@Composable
internal fun AboutScreen(onBack: () -> Unit) {
    val ctx = LocalContext.current
    val version = remember { appVersionText(ctx) }
    // hudba hraje po dobu, co je obrazovka otevrena; vpravo nahore cas a pauza / prehrat
    val music = rememberMusic()
    val musicControl: (@Composable () -> Unit)? = if (music.player == null) null else ({ MusicControl(music) })
    // pozadi UFO Field pod celou obrazovkou, obsah je pres nej (karty jsou polopruhledne)
    UfoBackground {
    ScreenScaffold(title = "O aplikaci", onBack = onBack, containerColor = Color.Transparent, trailing = musicControl) {
        Column(
            Modifier.weight(1f).fillMaxWidth().verticalScroll(rememberScrollState()).padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Column(Modifier.fillMaxWidth().padding(vertical = 8.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Image(painterResource(R.drawable.asap_logo), contentDescription = null, modifier = Modifier.width(150.dp), contentScale = ContentScale.Fit)
                Spacer(Modifier.height(10.dp))
                Text("ASAP Browser", color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(2.dp))
                Text(version, color = MUTED, fontSize = 13.sp)
            }
            Text(
                "Rychlý a příjemný prohlížeč s jednoduchou, ale propracovanou konfigurací: blokování reklam, gesta a ovládání, které si celé přizpůsobíš.",
                color = Color(0xFFDDDDDD), fontSize = 14.sp, lineHeight = 20.sp
            )
            AboutCard(
                "Co umí", listOf(
                    "Blokování reklam (i na YouTube) a automatické odmítání cookie lišt",
                    "Gesta: kódy kreslené prstem po ploše 3×3",
                    "Tlačítka s vlastními funkcemi pro klepnutí a držení",
                    "Karty ve složkách a anonymní karty",
                    "Záložky, historie a stahování",
                    "Screenshoty včetně celé stránky",
                    "Export a import celého nastavení"
                )
            )
            AboutCard("Připravuje se", listOf("VPN", "Profily (oddělená nastavení, záložky a přihlášení)"))
            AboutCard(
                "Soukromí", listOf(
                    "Bez účtu a bez sledování používání aplikace",
                    "Anonymní karty neukládají historii ani náhledy a jejich cookies se po zavření poslední anonymní karty smažou"
                )
            )
            AboutCard(
                "Použité součásti", listOf(
                    "Android WebView (Chromium) jako prohlížecí jádro",
                    "EasyList a EasyPrivacy: seznamy filtrů pro blokování reklam (easylist.to)",
                    "ZXing: tvorba QR kódů (Apache License 2.0)",
                    "AndroidX, Jetpack Compose a Material Components (Apache License 2.0)",
                    "Vlastní jádro v Rustu pro rychlé filtrování požadavků"
                )
            )
            ErrorLogCard()
            Spacer(Modifier.height(16.dp))
        }
    }
    }
}

// Log chyb: jen v telefonu; uzivatel ho posle sam (e-mail, zprava...), nikam se neposila automaticky
@Composable
private fun ErrorLogCard() {
    val ctx = LocalContext.current
    var hasLog by remember { mutableStateOf(com.example.actimelteambrowser.core.ErrorLog.text(ctx) != null) }
    Column(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(Color(0xD91E1E1E))
            .padding(horizontal = 18.dp, vertical = 16.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        Text("Log chyb", color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold)
        Text(
            if (hasLog) "Chyby se zapisují jen do telefonu. Pokud něco nefunguje, můžeš log sám poslat – nikam se neposílá automaticky."
            else "Zatím se nezapsala žádná chyba.",
            color = Color(0xFFCCCCCC), fontSize = 13.sp, lineHeight = 19.sp
        )
        if (hasLog) Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            TextButton(onClick = { sendErrorLog(ctx) }) { Text("Poslat log", color = Color(0xFF00E676), fontWeight = FontWeight.Bold) }
            TextButton(onClick = { com.example.actimelteambrowser.core.ErrorLog.clear(); hasLog = false }) { Text("Smazat log", color = MUTED) }
        }
    }
}

private fun sendErrorLog(ctx: android.content.Context) {
    val text = com.example.actimelteambrowser.core.ErrorLog.text(ctx) ?: return
    runCatching {
        val dir = java.io.File(ctx.cacheDir, com.example.actimelteambrowser.ExportFileProvider.DIR)
        dir.mkdirs()
        val f = java.io.File(dir, "asap-browser-log.txt")
        f.writeText(text)
        val uri = com.example.actimelteambrowser.ExportFileProvider.uriFor(ctx, f.name)
        val send = android.content.Intent(android.content.Intent.ACTION_SEND)
        send.type = "text/plain"
        send.putExtra(android.content.Intent.EXTRA_SUBJECT, "ASAP Browser – log chyb")
        send.putExtra(android.content.Intent.EXTRA_STREAM, uri)
        send.clipData = android.content.ClipData.newRawUri("", uri)
        send.addFlags(android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION)
        ctx.startActivity(android.content.Intent.createChooser(send, "Poslat log chyb"))
    }
}

@Composable
private fun AboutCard(title: String, lines: List<String>) {
    Column(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(Color(0xD91E1E1E))   // polopruhledne, aby bylo videt pozadi
            .padding(horizontal = 18.dp, vertical = 16.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        Text(title, color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold)
        lines.forEach { Text("•  $it", color = Color(0xFFCCCCCC), fontSize = 13.sp, lineHeight = 19.sp) }
    }
}


/** Stav hudby na obrazovce (bez_zastaveni_full.mp3). */
internal class MusicState {
    var player by mutableStateOf<MediaPlayer?>(null)
    var playing by mutableStateOf(false)
    var posMs by mutableStateOf(0)
    var durMs by mutableStateOf(0)
}

/**
 * Hudba hraje, dokud je obrazovka otevrena; po odchodu se zastavi (prepinac zvuku se nekontroluje).
 * [volume] 0..1 (Hodnoceni a chyby hraje potise), [enabled] = false: nic nehraje (napr. ukazka).
 */
@Composable
internal fun rememberMusic(volume: Float = 1f, enabled: Boolean = true): MusicState {
    val ctx = LocalContext.current
    val st = remember { MusicState() }
    DisposableEffect(Unit) {
        var mp: MediaPlayer? = null
        if (enabled) try {
            @Suppress("DiscouragedApi")
            val resId = ctx.resources.getIdentifier("bez_zastaveni_full", "raw", ctx.packageName)
            if (resId != 0) {
                val attrs = AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                    .build()
                mp = MediaPlayer.create(ctx.applicationContext, resId, attrs, android.media.AudioManager.AUDIO_SESSION_ID_GENERATE)
                mp?.setVolume(volume, volume)
                mp?.setOnCompletionListener { st.playing = false; st.posMs = 0; runCatching { it.seekTo(0) } }
                mp?.start()
                st.durMs = mp?.duration ?: 0
                st.playing = mp != null
                st.player = mp
            }
        } catch (e: Exception) {
            android.util.Log.d("music", e.toString())   // hudba je jen bonus, nesmi shodit obrazovku
        }
        onDispose {
            st.player = null
            try { mp?.stop() } catch (_: Exception) { }
            mp?.release()
            mp = null
        }
    }
    // casovac: obnovuje se 2x za sekundu, jen kdyz hraje
    LaunchedEffect(st.playing) {
        while (st.playing) {
            st.posMs = runCatching { st.player?.currentPosition ?: 0 }.getOrDefault(0)
            kotlinx.coroutines.delay(500)
        }
    }
    return st
}

/** Vpravo nahore: cas prehravani a pauza / prehrat. */
@Composable
internal fun MusicControl(st: MusicState) {
    fun mmss(ms: Int): String { val s = ms / 1000; return "%d:%02d".format(s / 60, s % 60) }
    Row(
        Modifier.clip(RoundedCornerShape(14.dp)).background(Color(0xD92A2A2A)).padding(start = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(mmss(st.posMs) + (if (st.durMs > 0) " / " + mmss(st.durMs) else ""), color = Color(0xFFDDDDDD), fontSize = 13.sp)
        Box(
            Modifier.size(40.dp).clip(RoundedCornerShape(12.dp)).clickable {
                val mp = st.player ?: return@clickable
                runCatching { if (st.playing) mp.pause() else mp.start() }
                st.playing = runCatching { mp.isPlaying }.getOrDefault(false)
            },
            contentAlignment = Alignment.Center
        ) {
            Text(if (st.playing) "❚❚" else "▶", color = Color(0xFF00B055), fontSize = if (st.playing) 14.sp else 18.sp, fontWeight = FontWeight.Bold)
        }
    }
}
